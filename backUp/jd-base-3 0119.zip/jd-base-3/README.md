## 请仔细阅读[WIKI](https://github.com/EvineDeng/jd-base/wiki)和各文件注释，90%的问题都能找到答案

## 如有帮助到你，请点亮Star

## 如有二次使用，请注明来源

本脚本是[https://github.com/LXK9301/jd_scripts](https://github.com/LXK9301/jd_scripts)的shell套壳工具，适用于以下系统：

- ArmBian/Debian/Ubuntu/OpenMediaVault/CentOS/Fedora/RHEL等Linux系统

- OpenWRT

- Android

- MacOS

- Docker

## 说明

1. 宠汪汪赛跑助力先让用户提供的各个账号之间相互助力，助力完成你提供的所有账号以后，再给我和lxk0301大佬助力，每个账号助力后可得30g狗粮。

2. 将部分临时活动修改为了我的邀请码，已取得lxk0301大佬的同意。

## 更新日志

> 只记录大的更新，小修小改不记录。

2021-01-15，每天定时任务中git_pull.sh只执行2次；每天12:00前运行git_pull.sh时随机生成当天下午执行git_pull.sh的任务时间，生成的时间范围：13:00-20:59；每天12:00后运行git_pull.sh时随机生成第二天上行执行git_pull.sh的任务时间，生成的时间范围：7:00-11:59；不影响手动执行，手动执行会刷新下一次git_pull.sh的执行时间。如果本机上安装了pm2，则挂机程序以pm2启动，否则以nohup启动。

## Star趋势

[![Stargazers over time](https://starchart.cc/EvineDeng/jd-base.svg)](https://starchart.cc/EvineDeng/jd-base)
